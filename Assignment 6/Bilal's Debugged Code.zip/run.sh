echo "-------------START PROGRAM-------------"

#ASM
nasm -g -F dwarf -f elf64 -o main.o main.asm

/usr/local/nasm-2.14.02/bin/nasm -g -F dwarf -f elf64 -o getfrequency.o getfrequency.asm

/usr/local/nasm-2.14.02/bin/nasm -g -F dwarf -f elf64 -o read_clock.o read_clock.asm

#C
gcc -c -g -Wall -m64 -no-pie -o driver.o driver.c -std=c11

#Linking
g++ -m64 -no-pie -o a.out -std=c++17 main.o driver.o getfrequency.o read_clock.o

./a.out

echo "\n\n\n-------------END PROGRAM-------------"

