#include <stdio.h>

double calculateTime();

int main(void) {
    double answer;

    answer = calculateTime();

    printf("hello, world\n");
    printf("%s%lf", "The main got ", answer);

    return 0;
}
